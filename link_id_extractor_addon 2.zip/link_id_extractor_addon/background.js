// Currently unused. Can add background functionality here.
console.log("Background script running...");
